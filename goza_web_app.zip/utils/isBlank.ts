export default function isBlank(str: string) {
    return !str.trim().length
}