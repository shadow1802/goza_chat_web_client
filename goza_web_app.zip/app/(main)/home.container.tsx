"use client"

import { FC, useEffect } from "react"

type Props = {}

const HomeContainer: FC<Props> = (props) => {

    return <div className="bg-gray-200 w-full min-h-full">
        <div className="w-full">
            
        </div>
    </div>
}

export default HomeContainer
