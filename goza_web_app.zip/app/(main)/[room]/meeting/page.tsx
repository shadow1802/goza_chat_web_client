import MeetingView from "./meeting.view";

export default function Meeting(){
    return <main className="">
        <MeetingView />
    </main>
}