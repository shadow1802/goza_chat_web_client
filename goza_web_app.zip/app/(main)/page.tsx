import Loader from "@/components/loader";
import HomeContainer from "./home.container";

export default async function Home() {

    return <div className="page">
        <HomeContainer />
    </div>
}