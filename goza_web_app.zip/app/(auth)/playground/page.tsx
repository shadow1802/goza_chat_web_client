import PlayGroundContainer from "./playground.container";

export default function PlayGround() {
    return <PlayGroundContainer />
}