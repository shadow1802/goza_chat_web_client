import RegisterContainer from "./register.container";

export default function Register () {
    return <>
        <RegisterContainer />
    </>
}