"use client"
import { IMessage } from "@/types/message"
import { dateTimeConverter } from "@/utils/dateTimeConverter"
import { FC, Dispatch, SetStateAction } from "react"
import Menu from "../menu"
import { useRoomContext } from "@/context/Room.context"
import { FaHeart, FaSadCry, FaAngry, FaSmile } from "react-icons/fa"
import log from "@/utils/logger"
import MessageCardMenu from "./message.card.menu"
import { IoReturnDownForwardSharp } from "react-icons/io5"
import { ROOM_ROLES_COLORS } from "@/constants/room.roles"
import { IMAGE_TYPES, VIDEO_TYPES } from "@/constants/file.types"
import useAuthValue from "@/utils/useAuthValue"

type Props = {
    message: IMessage,
    setMessageEditor: Dispatch<SetStateAction<IMessage | null>>,
    setMessageReplySender: Dispatch<SetStateAction<IMessage | null>>,
    handleRemoveMessage: (id: string) => void
    prevMessage?: IMessage | null,
    handleReaction: (message: IMessage, emoji: string) => void,
}

const MessageCard: FC<Props> = ({ message, setMessageEditor, handleRemoveMessage, setMessageReplySender, prevMessage, handleReaction }) => {

    const { roomDetail } = useRoomContext()
    const authValue = useAuthValue()
    const memberDetail = roomDetail?.roomUsers.find(item => item.user._id === message.createdBy._id)
    const isSameUser = prevMessage?.createdBy._id === message.createdBy._id

    const counter = message.reactions

    const FileRender: FC<{ file: string }> = ({ file }) => {
        let type = "document"
        const ext = file.split(".").pop()
        if (ext && IMAGE_TYPES.includes(ext)) {
            type = "image"
        }
        if (ext && VIDEO_TYPES.includes(ext)) {
            type = "video"
        }

        return <div>
            {type === "video" && <video className="w-[350px]" src={file} controls></video>}
            {type === "image" && <img src={file} className="w-[350px]" />}
        </div>
    }

    const isSameCreator = authValue?.user._id === message.createdBy._id

    return <MessageCardMenu message={message} setMessageEditor={setMessageEditor} handleRemoveMessage={handleRemoveMessage} setMessageReplySender={setMessageReplySender} handleReaction={handleReaction}>
        {isSameCreator ? <div id={message._id} className="msg_direction px-7 w-full flex justify-start">

            <div onClick={() => console.log(message)} className="msg_container p-2 flex items-start max-w-[500px] space-x-2">

                {!isSameUser ? <img src={message.createdBy.avatar || '/images/default-avatar.jpg'} className="border-2 border-sky-500 w-14 h-14 rounded-full" /> : <div className="w-14"></div>}
                <div className="bg-sky-500 rounded-lg shadow-lg p-3">
                    {message.replyTo && <div className="border-2 px-2 rounded-lg">
                        <p>Trả lời tin nhắn của {message.replyTo.createdBy.fullName}:</p>
                        <p className="text-sm max-w-[500px] text-block-default">{message.replyTo.message}</p>
                        {message.replyTo.file && <FileRender file={message.replyTo.message} />}
                    </div>}
                    {!isSameUser && <p className="font-semibold">{message.createdBy.fullName} <span className="text-xs text-gray-200">{dateTimeConverter(String(message.lastModified))}</span></p>}
                    <p className="text-sm max-w-[500px] text-block-default">{message.message}</p>
                    {message.file && <FileRender file={message.file} />}
                </div>
            </div>
        </div> : <div className="my-1 msg_direction px-7 w-full flex justify-end">
            <div className="msg_container flex items-start max-w-[500px] space-x-2">
                {!isSameUser && <img src={message.createdBy.avatar || '/images/default-avatar.jpg'} className="border-2 border-sky-500 w-14 h-14 rounded-full" />}
                <div className="p-3 bg-white rounded-lg shadow-lg">
                    {message.replyTo && <div className="border-2 px-2 rounded-lg">
                        <p>Trả lời tin nhắn của {message.replyTo.createdBy.fullName}:</p>
                        <p className="text-sm max-w-[500px] text-block-default">{message.replyTo.message}</p>
                        {message.replyTo.file && <FileRender file={message.replyTo.message} />}
                    </div>}
                    {!isSameUser && <p className="font-semibold text-gray-500">{message.createdBy.fullName} <span className="text-xs text-gray-400">{dateTimeConverter(String(message.lastModified))}</span></p>}
                    <p className="text-sm max-w-[500px] text-block-default text-black">{message.message}</p>
                    {message.file && <FileRender file={message.file} />}
                </div>
            </div>
        </div>}
    </MessageCardMenu>
}

export default MessageCard