const NOTIFY: { [key: string]:string } = {
    receive_message: 'Đã gửi cho bạn 1 tin nhắn',
    receive_friend: 'Đã thêm bạn vào danh sách bạn bè'
}

export default NOTIFY