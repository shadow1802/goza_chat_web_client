export const ROOM_ROLES: { [key:number]:string } = {
    0: "Chủ phòng",
    1: "Quản trị",
    2: "Thành viên"
}

export const ROOM_ROLES_COLORS: { [key:number]:string } = {
    0: "text-red-500",
    1: "text-yellow-500",
    2: "text-green-500"
}