export const VIDEO_TYPES = ["mp4", "flv", "mkv", "gif", "flv"]
export const IMAGE_TYPES = ["png", "jpg", "jpeg", "gif"]
export const AUDIO_TYPES = ["mp3", "wav"]