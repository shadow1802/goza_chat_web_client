export enum ROLES {
    SUPERADMIN = "SUPERADMIN",
    USER = "USER"
}