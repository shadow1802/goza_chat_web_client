# GOZA CHAT [WEB_APP] FEATURES

1. Đăng nhập

    * Mở rộng: đăng nhập => chuyển đến trang mời vào phòng

2. Đăng ký

3. Chỉnh sửa thông tin người dùng

	x Chưa update được avatar

4. Tạo phòng

    - Đặt ảnh nhóm

    - Thêm người dùng

5. Chat với admin
    - Chưa gửi được biểu cảm

    - Chưa sửa được tin nhắn

    - Chưa thể trả lời tin nhắn

    - Chưa thể gim tin nhắn

6. Chat nhóm

    - Chưa thể trả lời tin nhắn

    - Chưa thể gim tin nhắn

7. Phòng chat

    - Phát hiện người dùng trong phòng online

    - Chưa thể reply